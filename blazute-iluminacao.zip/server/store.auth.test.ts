import { describe, expect, it } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

function contextFor(role: "user" | "admin" | null): TrpcContext {
  const user = role ? {
    id: 1, openId: "store-test-user", email: "test@example.com", name: "Test User", loginMethod: "test", role,
    createdAt: new Date(), updatedAt: new Date(), lastSignedIn: new Date(),
  } : null;
  return { user, req: { protocol: "https", headers: {} } as TrpcContext["req"], res: {} as TrpcContext["res"] };
}

describe("store.adminReport access", () => {
  it("rejects unauthenticated visitors before accessing personal store data", async () => {
    const caller = appRouter.createCaller(contextFor(null));
    await expect(caller.store.adminReport()).rejects.toMatchObject({ code: "FORBIDDEN" });
  });

  it("rejects authenticated customers without the admin role", async () => {
    const caller = appRouter.createCaller(contextFor("user"));
    await expect(caller.store.adminReport()).rejects.toMatchObject({ code: "FORBIDDEN" });
  });
});
