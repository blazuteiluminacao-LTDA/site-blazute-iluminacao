import { desc, eq } from "drizzle-orm";
import { customers, orders } from "../drizzle/schema";
import { getDb } from "./db";

export async function getAdminReport() {
  const db = await getDb();
  if (!db) throw new Error("Banco de dados indisponível.");
  const [recentOrders, recentCustomers] = await Promise.all([
    db.select({
      reference: orders.reference,
      status: orders.status,
      amountCents: orders.amountCents,
      recurrenceMonths: orders.recurrenceMonths,
      items: orders.items,
      shippingAddress: orders.shippingAddress,
      createdAt: orders.createdAt,
      customerName: customers.name,
      customerEmail: customers.email,
    }).from(orders).leftJoin(customers, eq(orders.customerId, customers.id))
      .orderBy(desc(orders.createdAt)).limit(50),
    db.select({ id: customers.id, name: customers.name, email: customers.email, phone: customers.phone, createdAt: customers.createdAt })
      .from(customers).orderBy(desc(customers.createdAt)).limit(100),
  ]);
  return { orders: recentOrders, customers: recentCustomers };
}
