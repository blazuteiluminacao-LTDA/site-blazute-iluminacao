import { describe, expect, it } from "vitest";
import { companyInfo, formatCnpj } from "../shared/companyInfo";
import { normalizeWhatsAppNumber } from "../shared/whatsappQuote";

describe("dados cadastrais da Blazute", () => {
  it("formata o CNPJ informado", () => {
    expect(companyInfo.cnpj).toBe("62.881.997/0001-93");
    expect(formatCnpj("62.881.997/0001-93")).toBe("62.881.997/0001-93");
  });

  it("rejeita números que não tenham 14 dígitos", () => {
    expect(() => formatCnpj("1234567890")).toThrow("CNPJ inválido");
  });

  it("mantém o WhatsApp comercial informado como destino válido", () => {
    expect(normalizeWhatsAppNumber(companyInfo.whatsapp)).toBe("5562986060011");
  });

  it("contém os dados essenciais de razão social, endereço e atividade", () => {
    expect(companyInfo).toMatchObject({
      legalName: "Blazute & Lisboa LTDA",
      tradeName: "Blazute Iluminação",
      address: "Rua RB 3, s/n, Quadra 2, Lote 38",
      neighborhood: "Residencial Buriti",
      city: "Senador Canedo",
      state: "GO",
      postalCode: "75260-384",
      whatsapp: "(62) 98606-0011",
      activity: "Comércio varejista de artigos de iluminação (CNAE 47.54-7/03)",
    });
  });
});
