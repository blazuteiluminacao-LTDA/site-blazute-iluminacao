import { describe, expect, it } from "vitest";
import { buildWhatsAppMessageUrl, buildWhatsAppQuoteUrl, normalizeWhatsAppNumber } from "../shared/whatsappQuote";

describe("orçamento pré-preenchido do WhatsApp", () => {
  it("normalizes the supplied Brazilian mobile number", () => {
    expect(normalizeWhatsAppNumber("62986060011")).toBe("5562986060011");
    expect(normalizeWhatsAppNumber("+55 (62) 98606-0011")).toBe("5562986060011");
  });

  it("includes products, quantities, SMD variants, prices, subtotal and freight note", () => {
    const url = buildWhatsAppQuoteUrl("62986060011", [
      { productName: "Luminária pública SMD 100W", quantity: 2, unitAmountCents: 8489, variant: 'braço 2,5" · com base relê + relê' },
      { productName: "Luminária pública COB 50W", quantity: 1, unitAmountCents: 3490 },
    ], 20468);
    const message = (new URL(url).searchParams.get("text") ?? "").replace(/\u00a0/g, " ");
    expect(url).toContain("https://wa.me/5562986060011?");
    expect(message).toContain("2× Luminária pública SMD 100W");
    expect(message).toContain('braço 2,5" · com base relê + relê');
    expect(message).toContain("1× Luminária pública COB 50W");
    expect(message).toContain("Subtotal dos produtos: R$ 204,68");
    expect(message).toContain("Frete combinado à parte.");
  });

  it("rejects inconsistent subtotals, invalid quantities and unsafe cents", () => {
    expect(() => buildWhatsAppQuoteUrl("62986060011", [
      { productName: "Luminária pública COB 50W", quantity: 2, unitAmountCents: 3490 },
    ], 3490)).toThrow("não corresponde");
    expect(() => buildWhatsAppQuoteUrl("62986060011", [
      { productName: "Luminária pública COB 50W", quantity: 0, unitAmountCents: 3490 },
    ], 0)).toThrow("faixa segura");
    expect(() => buildWhatsAppQuoteUrl("62986060011", [
      { productName: "Luminária pública COB 50W", quantity: Number.MAX_SAFE_INTEGER, unitAmountCents: 3490 },
    ], 0)).toThrow("faixa segura");
  });

  it("rejects numbers without a valid Brazilian area code/length", () => {
    expect(() => normalizeWhatsAppNumber("1234")).toThrow("Informe um WhatsApp válido");
  });

  it("prepares the exact new fixed message used by the floating contact button", () => {
    const url = buildWhatsAppMessageUrl("62986060011", "Olá! Vi o portfólio de luminárias públicas e gostaria de mais informações.");
    expect(url).toContain("https://wa.me/5562986060011?");
    expect(new URL(url).searchParams.get("text")).toBe("Olá! Vi o portfólio de luminárias públicas e gostaria de mais informações.");
    expect(() => buildWhatsAppMessageUrl("62986060011", "   ")).toThrow("Escreva uma mensagem");
  });
});
