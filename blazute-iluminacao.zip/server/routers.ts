import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { adminProcedure, publicProcedure, router } from "./_core/trpc";
import { TRPCError } from "@trpc/server";
import { z } from "zod";
import { createCheckout } from "./store";
import { getAdminReport } from "./storeAdmin";

const checkoutInput = z.object({
  name: z.string().trim().min(2).max(191),
  email: z.string().email().max(320),
  phone: z.string().trim().max(40).optional(),
  items: z.array(z.object({
    productId: z.string().max(40),
    quantity: z.number().int().min(1).max(Number.MAX_SAFE_INTEGER),
    armSize: z.enum(["2", "2.5"]).optional(),
    relay: z.boolean().optional(),
  })).min(1).max(30),
  recurrenceMonths: z.union([z.literal(0), z.literal(1), z.literal(3), z.literal(6), z.literal(12)]),
});

export const appRouter = router({
    // if you need to use socket.io, read and register route in server/_core/index.ts, all api should start with '/api/' so that the gateway can route correctly
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  store: router({
    createCheckout: publicProcedure.input(checkoutInput).mutation(async ({ ctx, input }) => {
      const rawOrigin = ctx.req.get("origin");
      const requestHost = ctx.req.get("host")?.toLowerCase();
      let origin: string;
      try {
        const parsedOrigin = new URL(rawOrigin ?? "");
        const isLocalHttp = parsedOrigin.protocol === "http:" && ["localhost", "127.0.0.1"].includes(parsedOrigin.hostname);
        if (!requestHost || parsedOrigin.host.toLowerCase() !== requestHost || (parsedOrigin.protocol !== "https:" && !isLocalHttp)) throw new Error("invalid origin");
        origin = parsedOrigin.origin;
      } catch {
        throw new TRPCError({ code: "BAD_REQUEST", message: "Não foi possível validar a origem da loja." });
      }
      try {
        return await createCheckout({ ...input, origin });
      } catch (error) {
        const message = error instanceof Error ? error.message : "Falha ao preparar o pagamento.";
        if (message.includes("ainda não foi habilitado") || message.includes("indisponível")) {
          throw new TRPCError({ code: "PRECONDITION_FAILED", message });
        }
        if (message.includes("Escolha") || message.includes("inválid") || message.includes("carrinho")) {
          throw new TRPCError({ code: "BAD_REQUEST", message });
        }
        console.error("[Store] Checkout could not be created:", message);
        throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Não foi possível iniciar o checkout. Tente novamente em instantes." });
      }
    }),
    adminReport: adminProcedure.query(async () => {
      try {
        return await getAdminReport();
      } catch (error) {
        console.error("[Store] Admin report unavailable:", error instanceof Error ? error.message : "Unknown error");
        throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Não foi possível carregar os registros da loja." });
      }
    }),
  }),

  // TODO: add feature routers here, e.g.
  // todo: router({
  //   list: protectedProcedure.query(({ ctx }) =>
  //     db.getUserTodos(ctx.user.id)
  //   ),
  // }),
});

export type AppRouter = typeof appRouter;
