import { describe, expect, it } from "vitest";
import { isInteractiveProductCardTag, shouldOpenProductFromCardClick, shouldOpenProductFromCardKey } from "../shared/productCardInteraction";

describe("interação do cartão de produto", () => {
  it("abre a ficha ao clicar numa área do cartão que não seja controle", () => {
    expect(shouldOpenProductFromCardClick(false)).toBe(true);
  });

  it("não abre a ficha quando o cliente clica no botão ou outro controle", () => {
    expect(shouldOpenProductFromCardClick(true)).toBe(false);
    expect(isInteractiveProductCardTag("BUTTON")).toBe(true);
    expect(isInteractiveProductCardTag("input")).toBe(true);
    expect(isInteractiveProductCardTag("a")).toBe(true);
    expect(isInteractiveProductCardTag("select")).toBe(true);
  });

  it("abre por teclado com Enter/Espaço apenas quando o cartão está focado", () => {
    expect(shouldOpenProductFromCardKey("Enter", true)).toBe(true);
    expect(shouldOpenProductFromCardKey(" ", true)).toBe(true);
    expect(shouldOpenProductFromCardKey("Escape", true)).toBe(false);
    expect(shouldOpenProductFromCardKey("Enter", false)).toBe(false);
  });
});
