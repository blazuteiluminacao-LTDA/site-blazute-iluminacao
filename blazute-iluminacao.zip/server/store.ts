import { randomUUID } from "node:crypto";
import Stripe from "stripe";
import { and, eq } from "drizzle-orm";
import { customers, orders } from "../drizzle/schema";
import { priceCart, cartTotalCents, subscriptionInterval, type CartChoice } from "../shared/cart";
import { getDb } from "./db";

const stripe = () => {
  const key = process.env.STRIPE_SECRET_KEY;
  if (!key) throw new Error("O pagamento online ainda não foi habilitado. Configure o Stripe em Configurações → Pagamentos.");
  return new Stripe(key);
};

export type CheckoutInput = {
  name: string;
  email: string;
  phone?: string;
  items: CartChoice[];
  recurrenceMonths: number;
  origin: string;
};

export async function createCheckout(input: CheckoutInput) {
  const db = await getDb();
  if (!db) throw new Error("Banco de dados indisponível no momento.");
  const paymentProvider = stripe();
  const recurrence = subscriptionInterval(input.recurrenceMonths);
  const lines = priceCart(input.items);
  const amountCents = cartTotalCents(lines);
  const reference = randomUUID();
  const email = input.email.trim().toLowerCase();

  await db.insert(customers).values({ name: input.name.trim(), email, phone: input.phone?.trim() || null })
    .onDuplicateKeyUpdate({ set: { name: input.name.trim(), phone: input.phone?.trim() || null } });
  const [customer] = await db.select({ id: customers.id, stripeCustomerId: customers.stripeCustomerId })
    .from(customers).where(eq(customers.email, email)).limit(1);
  if (!customer) throw new Error("Não foi possível salvar o cadastro do cliente.");

  const serializedItems = JSON.stringify(lines.map(line => ({
    productId: line.product.id,
    productName: line.product.title,
    quantity: line.quantity,
    unitAmountCents: line.unitAmountCents,
    label: line.label,
    armSize: line.armSize ?? null,
    relay: line.relay ?? false,
  })));
  await db.insert(orders).values({
    reference,
    customerId: customer.id,
    items: serializedItems,
    amountCents,
    recurrenceMonths: input.recurrenceMonths,
    currency: "brl",
  });

  try {
    const mode = recurrence ? "subscription" : "payment";
    const session = await paymentProvider.checkout.sessions.create({
      mode,
      line_items: lines.map(line => ({
        quantity: line.quantity,
        price_data: {
          currency: "brl",
          unit_amount: line.unitAmountCents,
          product_data: { name: line.label },
          ...(recurrence ? { recurring: recurrence } : {}),
        },
      })),
      customer_email: email,
      client_reference_id: reference,
      allow_promotion_codes: true,
      metadata: {
        order_reference: reference,
        user_id: String(customer.id),
      customer_email: email,
        customer_name: input.name.trim(),
      },
      ...(mode === "subscription" ? {
        subscription_data: { metadata: { order_reference: reference, customer_id: String(customer.id) } },
      } : { customer_creation: "always" as const }),
      phone_number_collection: { enabled: true },
      shipping_address_collection: { allowed_countries: ["BR"] },
      custom_text: { submit: { message: "O valor do frete é combinado separadamente e não está incluído no subtotal mostrado." } },
      success_url: `${input.origin}/?checkout=success&ref=${reference}`,
      cancel_url: `${input.origin}/?checkout=cancelled&ref=${reference}`,
    });
    await db.update(orders).set({ stripeCheckoutSessionId: session.id })
      .where(eq(orders.reference, reference));
    if (!session.url) throw new Error("O Stripe não devolveu um link de pagamento.");
    return { url: session.url, reference, amountCents };
  } catch (error) {
    await db.update(orders).set({ status: "failed" }).where(and(eq(orders.reference, reference), eq(orders.status, "pending")));
    throw error;
  }
}

export async function handleStripeWebhook(rawBody: Buffer, signature: string | undefined) {
  const secret = process.env.STRIPE_WEBHOOK_SECRET;
  if (!secret) throw new Error("A assinatura do webhook não está configurada.");
  const event = stripe().webhooks.constructEvent(rawBody, signature ?? "", secret);
  if (event.id.startsWith("evt_test_")) {
    console.log("[Webhook] Test event detected, returning verification response");
    return { verified: true } as const;
  }

  const db = await getDb();
  if (!db) throw new Error("Banco de dados indisponível.");
  if (event.type === "checkout.session.completed") {
    const session = event.data.object as Stripe.Checkout.Session;
    const reference = session.metadata?.order_reference ?? session.client_reference_id;
    if (reference) {
      const paymentIntentId = typeof session.payment_intent === "string" ? session.payment_intent : session.payment_intent?.id;
      const subscriptionId = typeof session.subscription === "string" ? session.subscription : session.subscription?.id;
      const shipping = session.collected_information?.shipping_details;
      const shippingAddress = shipping?.address ? JSON.stringify({
        name: shipping.name ?? null,
        line1: shipping.address.line1 ?? null,
        line2: shipping.address.line2 ?? null,
        city: shipping.address.city ?? null,
        state: shipping.address.state ?? null,
        postalCode: shipping.address.postal_code ?? null,
        country: shipping.address.country ?? null,
      }) : null;
      await db.update(orders).set({
        status: session.payment_status === "paid" || session.payment_status === "no_payment_required" ? "paid" : "pending",
        stripePaymentIntentId: paymentIntentId ?? null,
        stripeSubscriptionId: subscriptionId ?? null,
        shippingAddress,
      }).where(eq(orders.reference, reference));
      if (session.customer && session.customer_email) {
        await db.update(customers).set({ stripeCustomerId: String(session.customer) })
          .where(eq(customers.email, session.customer_email.toLowerCase()));
      }
    }
  }
  if (event.type === "invoice.paid" || event.type === "invoice.payment_failed") {
    const invoice = event.data.object as Stripe.Invoice & {
      subscription?: string | Stripe.Subscription | null;
      parent?: { subscription_details?: { subscription?: string | Stripe.Subscription | null } } | null;
    };
    const subscription = invoice.subscription ?? invoice.parent?.subscription_details?.subscription;
    const subscriptionId = typeof subscription === "string" ? subscription : subscription?.id;
    if (subscriptionId) {
      await db.update(orders).set({ status: event.type === "invoice.paid" ? "paid" : "failed" })
        .where(eq(orders.stripeSubscriptionId, subscriptionId));
    }
  }
  if (event.type === "customer.subscription.deleted") {
    const subscription = event.data.object as Stripe.Subscription;
    await db.update(orders).set({ status: "cancelled" })
      .where(eq(orders.stripeSubscriptionId, subscription.id));
  }
  console.log(`[Stripe webhook] ${event.type} ${event.id} ${new Date(event.created * 1000).toISOString()}`);
  return { received: true } as const;
}
