import { describe, expect, it } from "vitest";
import {
  addRequestedQuantities,
  calculateLineAmountCents,
  cartTotalCents,
  defaultCartChoiceForProduct,
  formatCartVariant,
  getUnitAmountCents,
  normalizeRequestedQuantity,
  priceCart,
  subscriptionInterval,
  sumSafeCents,
  tryNormalizeRequestedQuantity,
} from "../shared/cart";
import { formatBRL, getCatalogProduct, getStartingPriceCents, products } from "../shared/catalog";

describe("catálogo e carrinho Blazute", () => {
  it("contém os 5 preços SMD e os 6 preços COB informados", () => {
    expect(products.filter(p => p.category === "SMD").map(p => p.priceCents)).toEqual([3849, 4388, 6189, 9382, 11920]);
    expect(products.filter(p => p.category === "COB").map(p => p.priceCents)).toEqual([3490, 6490, 8490, 9990, 15490, 24990]);
  });

  it("aplica R$ 23 de base relê por unidade e soma quantidades corretamente", () => {
    const lines = priceCart([{ productId: "smd-50", quantity: 2, armSize: "2.5", relay: true }]);
    expect(lines[0].unitAmountCents).toBe(6149);
    expect(cartTotalCents(lines)).toBe(12298);
  });

  it("compartilha preço e variante canônicos com o carrinho e o orçamento", () => {
    const product = getCatalogProduct("smd-50");
    expect(getUnitAmountCents(product, { relay: true })).toBe(6149);
    expect(formatCartVariant(product, { armSize: "2.5", relay: true })).toBe('braço 2,5" · com base relê + relê');
    expect(formatCartVariant(getCatalogProduct("cob-50"), {})).toBe("linha COB");
  });

  it("cobra COB pelo valor de catálogo e exige diâmetro para SMD", () => {
    expect(priceCart([{ productId: "cob-50", quantity: 1 }])[0].lineAmountCents).toBe(3490);
    expect(() => priceCart([{ productId: "smd-60", quantity: 1 }])).toThrow("Escolha o diâmetro do braço");
  });

  it("adiciona direto com braço de 2 polegadas na SMD e sem variantes na COB", () => {
    expect(defaultCartChoiceForProduct({ id: "smd-50", category: "SMD" })).toEqual({ productId: "smd-50", quantity: 1, armSize: "2", relay: false });
    expect(defaultCartChoiceForProduct({ id: "cob-50", category: "COB" })).toEqual({ productId: "cob-50", quantity: 1 });
  });

  it("rejeita produtos desconhecidos e quantidades inválidas, sem limitar unidades a 99", () => {
    expect(() => priceCart([{ productId: "inventado", quantity: 1 }])).toThrow("Produto inválido");
    expect(priceCart([{ productId: "cob-50", quantity: 100 }])[0].lineAmountCents).toBe(349000);
    expect(priceCart([{ productId: "cob-50", quantity: 1000 }])[0].lineAmountCents).toBe(3490000);
    expect(() => priceCart([{ productId: "cob-50", quantity: 0 }])).toThrow("Quantidade inválida");
    expect(() => priceCart([{ productId: "cob-50", quantity: 1.5 }])).toThrow("Quantidade inválida");
  });

  it("não aplica teto comercial, mas rejeita entradas acima da precisão inteira segura", () => {
    expect(["", "0", "2", "2.8", "150", "1000"].map(normalizeRequestedQuantity)).toEqual([1, 1, 2, 2, 150, 1000]);
    expect(addRequestedQuantities(150, 300)).toBe(450);
    expect(tryNormalizeRequestedQuantity(String(Number.MAX_SAFE_INTEGER))).toBe(Number.MAX_SAFE_INTEGER);
    expect(tryNormalizeRequestedQuantity(String(Number.MAX_SAFE_INTEGER + 1))).toBeNull();
    expect(() => normalizeRequestedQuantity(String(Number.MAX_SAFE_INTEGER + 1))).toThrow("precisão");
    expect(() => addRequestedQuantities(Number.MAX_SAFE_INTEGER, 1)).toThrow("precisão");
  });

  it("rejeita overflow de subtotal por item e do total combinado", () => {
    expect(calculateLineAmountCents(3849, 1000)).toBe(3849000);
    expect(() => calculateLineAmountCents(24990, Number.MAX_SAFE_INTEGER)).toThrow("faixa segura");
    expect(() => sumSafeCents([Number.MAX_SAFE_INTEGER, 1])).toThrow("faixa segura");
    const valid = priceCart([{ productId: "cob-50", quantity: 1 }])[0];
    const unsafe = { ...valid, lineAmountCents: Number.MAX_SAFE_INTEGER };
    expect(() => cartTotalCents([unsafe, valid])).toThrow("faixa segura");
  });

  it("formata centavos com exatidão, inclusive números grandes", () => {
    expect(formatBRL(3849).replace(/\u00a0/g, " ")).toBe("R$ 38,49");
    expect(formatBRL(9007199254740991).replace(/\u00a0/g, " ")).toBe("R$ 90.071.992.547.409,91");
    expect(() => formatBRL(Number.MAX_SAFE_INTEGER + 1)).toThrow("precisão");
  });

  it("deriva preço inicial e destaques hero diretamente do catálogo", () => {
    expect(getStartingPriceCents()).toBe(3490);
    expect(getCatalogProduct("smd-200").priceCents).toBe(11920);
    expect(getCatalogProduct("cob-200").priceCents).toBe(9990);
    expect(() => getCatalogProduct("missing")).toThrow("não encontrado");
  });

  it("forma assinaturas mensais, trimestrais, semestrais e anuais do Stripe", () => {
    expect([1, 3, 6, 12].map(subscriptionInterval)).toEqual([
      { interval: "month", interval_count: 1 }, { interval: "month", interval_count: 3 },
      { interval: "month", interval_count: 6 }, { interval: "month", interval_count: 12 },
    ]);
    expect(subscriptionInterval(0)).toBeUndefined();
    expect(() => subscriptionInterval(2)).toThrow("Escolha uma frequência válida");
  });
});
