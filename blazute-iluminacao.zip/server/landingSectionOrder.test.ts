import { readFileSync } from "node:fs";
import { resolve } from "node:path";
import { describe, expect, it } from "vitest";

const home = readFileSync(resolve(process.cwd(), "client/src/pages/Home.tsx"), "utf8");
const position = (anchor: string) => {
  const index = home.indexOf(anchor);
  if (index < 0) throw new Error(`Missing landing section anchor: ${anchor}`);
  return index;
};

describe("ordem da página inicial da Blazute", () => {
  it("mostra as categorias SMD e COB antes do banner hero", () => {
    expect(position('id="smd"')).toBeLessThan(position('id="cob"'));
    expect(position('id="cob"')).toBeLessThan(position('<section className="hero container">'));
  });

  it("mantém os dados da empresa como a última seção de conteúdo antes do rodapé", () => {
    expect(position('<section className="hero container">')).toBeLessThan(position('className="last-call"'));
    expect(position('className="last-call"')).toBeLessThan(position('className="company-section container"'));
    expect(position('className="company-section container"')).toBeLessThan(position('</main>'));
    expect(position('</main>')).toBeLessThan(position('<footer className="site-footer"'));
  });

  it("deixa a faixa de confiança depois da categoria COB", () => {
    expect(position('id="cob"')).toBeLessThan(position('className="trust-rail"'));
  });
});
