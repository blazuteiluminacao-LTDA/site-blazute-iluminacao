export function formatCnpj(value: string) {
  const digits = value.replace(/\D/g, "");
  if (!/^\d{14}$/.test(digits)) throw new Error("CNPJ inválido.");
  return digits.replace(/^(\d{2})(\d{3})(\d{3})(\d{4})(\d{2})$/, "$1.$2.$3/$4-$5");
}

export const companyInfo = {
  tradeName: "Blazute Iluminação",
  legalName: "Blazute & Lisboa LTDA",
  cnpj: formatCnpj("62881997000193"),
  address: "Rua RB 3, s/n, Quadra 2, Lote 38",
  neighborhood: "Residencial Buriti",
  city: "Senador Canedo",
  state: "GO",
  postalCode: "75260-384",
  whatsapp: "(62) 98606-0011",
  activity: "Comércio varejista de artigos de iluminação (CNAE 47.54-7/03)",
} as const;
