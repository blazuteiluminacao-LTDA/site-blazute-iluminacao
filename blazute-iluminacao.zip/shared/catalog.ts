export type ProductSpec = {
  model: string;
  testVoltage: string;
  frequency: string;
  testPowerW: number;
  powerFactor: string;
  luminousFluxLm: string;
  efficacyLmW: number;
  cri: string;
  cct: string;
};

export type Product = {
  id: string;
  category: "SMD" | "COB";
  title: string;
  shortTitle: string;
  watts: number;
  priceCents: number;
  image: string;
  imageAlt: string;
  highlight?: string;
  model?: string;
  spec?: ProductSpec;
  ip66?: boolean;
  inmetro?: boolean;
};

const smdImage = "/manus-storage/smd-front_04d5653c.jpg";
const cobImage = "/manus-storage/cob-luminaria_e7b738a3.jpg";
const cob50Image = "/manus-storage/cob-50w_15a06314.jpg";

export const products: Product[] = [
  {
    id: "smd-50",
    category: "SMD",
    title: "Luminária pública SMD 50W",
    shortTitle: "50W",
    watts: 50,
    priceCents: 3849,
    image: smdImage,
    imageAlt: "Luminária pública LED SMD para instalação em poste",
    highlight: "114 lm/W",
    model: "LMP-0056",
    ip66: true,
    inmetro: true,
    spec: { model: "LMP-0056", testVoltage: "100–277V", frequency: "60 Hz", testPowerW: 60, powerFactor: "0,98", luminousFluxLm: "6.900", efficacyLmW: 114, cri: "70", cct: "5.000 K" },
  },
  {
    id: "smd-60",
    category: "SMD",
    title: "Luminária pública SMD 60W",
    shortTitle: "60W",
    watts: 60,
    priceCents: 4388,
    image: smdImage,
    imageAlt: "Luminária pública LED SMD para iluminação viária",
    highlight: "114 lm/W",
    model: "LMP-0056",
    ip66: true,
    inmetro: true,
    spec: { model: "LMP-0056", testVoltage: "100–277V", frequency: "60 Hz", testPowerW: 60, powerFactor: "0,98", luminousFluxLm: "6.900", efficacyLmW: 114, cri: "70", cct: "5.000 K" },
  },
  {
    id: "smd-100",
    category: "SMD",
    title: "Luminária pública SMD 100W",
    shortTitle: "100W",
    watts: 100,
    priceCents: 6189,
    image: smdImage,
    imageAlt: "Luminária pública LED SMD com corpo para instalação em poste",
    highlight: "143 lm/W",
    model: "LMP-0058",
    ip66: true,
    inmetro: true,
    spec: { model: "LMP-0058", testVoltage: "100–277V", frequency: "60 Hz", testPowerW: 100, powerFactor: "0,98", luminousFluxLm: "14.300", efficacyLmW: 143, cri: "70", cct: "5.000 K" },
  },
  {
    id: "smd-150",
    category: "SMD",
    title: "Luminária pública SMD 150W",
    shortTitle: "150W",
    watts: 150,
    priceCents: 9382,
    image: smdImage,
    imageAlt: "Luminária pública LED SMD para projetos de iluminação de ruas",
    highlight: "147 lm/W",
    model: "LMP-0062",
    ip66: true,
    inmetro: true,
    spec: { model: "LMP-0062", testVoltage: "100–277V", frequency: "60 Hz", testPowerW: 147, powerFactor: "0,98", luminousFluxLm: "22.275", efficacyLmW: 149, cri: "70", cct: "5.000 K" },
  },
  {
    id: "smd-200",
    category: "SMD",
    title: "Luminária pública SMD 200W",
    shortTitle: "200W",
    watts: 200,
    priceCents: 11920,
    image: smdImage,
    imageAlt: "Luminária pública LED SMD de alta potência para poste",
    highlight: "150 lm/W",
    model: "LMP-0065",
    ip66: true,
    inmetro: true,
    spec: { model: "LMP-0065", testVoltage: "100–277V", frequency: "60 Hz", testPowerW: 200, powerFactor: "0,98", luminousFluxLm: "30.000", efficacyLmW: 150, cri: "70", cct: "5.000 K" },
  },
  { id: "cob-50", category: "COB", title: "Luminária pública COB 50W", shortTitle: "50W", watts: 50, priceCents: 3490, image: cob50Image, imageAlt: "Luminária pública LED COB tipo pétala para poste", highlight: "COB" },
  { id: "cob-100", category: "COB", title: "Luminária pública COB 100W", shortTitle: "100W", watts: 100, priceCents: 6490, image: cobImage, imageAlt: "Luminária pública LED COB para instalação viária", highlight: "COB" },
  { id: "cob-150", category: "COB", title: "Luminária pública COB 150W", shortTitle: "150W", watts: 150, priceCents: 8490, image: cobImage, imageAlt: "Luminária pública LED COB de alta potência", highlight: "COB" },
  { id: "cob-200", category: "COB", title: "Luminária pública COB 200W", shortTitle: "200W", watts: 200, priceCents: 9990, image: cobImage, imageAlt: "Luminária pública LED COB de 200 watts para poste", highlight: "COB" },
  { id: "cob-300", category: "COB", title: "Luminária pública COB 300W", shortTitle: "300W", watts: 300, priceCents: 15490, image: cobImage, imageAlt: "Luminária pública LED COB para projetos urbanos", highlight: "COB" },
  { id: "cob-400", category: "COB", title: "Luminária pública COB 400W", shortTitle: "400W", watts: 400, priceCents: 24990, image: cobImage, imageAlt: "Luminária pública LED COB para postes de alta potência", highlight: "COB" },
];

export function getCatalogProduct(id: string): Product {
  const product = products.find(item => item.id === id);
  if (!product) throw new Error(`Produto do catálogo não encontrado: ${id}`);
  return product;
}

export function getStartingPriceCents(): number {
  return products.reduce((lowest, product) => Math.min(lowest, product.priceCents), Number.POSITIVE_INFINITY);
}

const formatBRLWhole = new Intl.NumberFormat("pt-BR", {
  style: "currency",
  currency: "BRL",
  maximumFractionDigits: 0,
});

/** Format safe integer cents while keeping the fractional cents exact. */
export function formatBRL(amountCents: number): string {
  if (!Number.isSafeInteger(amountCents)) {
    throw new RangeError("O valor em centavos não pode ser representado com precisão.");
  }
  const negative = amountCents < 0;
  const absolute = Math.abs(amountCents);
  const whole = Math.trunc(absolute / 100);
  const fraction = String(absolute % 100).padStart(2, "0");
  const formattedWhole = formatBRLWhole.format(negative ? -whole : whole);
  return `${formattedWhole},${fraction}`;
}
