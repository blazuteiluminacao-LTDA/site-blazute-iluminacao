import { products, type Product } from "./catalog";

export type CartChoice = {
  productId: string;
  quantity: number;
  armSize?: "2" | "2.5";
  relay?: boolean;
};

export type PricedCartLine = CartChoice & {
  product: Product;
  unitAmountCents: number;
  lineAmountCents: number;
  label: string;
};

export const RELAY_ADDON_CENTS = 2300;

const UNSAFE_AMOUNT_MESSAGE = "O valor ultrapassa a faixa segura de cálculo. Reduza a quantidade e tente novamente.";

export function defaultCartChoiceForProduct(product: Pick<Product, "id" | "category">): CartChoice {
  return product.category === "SMD"
    ? { productId: product.id, quantity: 1, armSize: "2", relay: false }
    : { productId: product.id, quantity: 1 };
}

/** Returns null for quantities too large to represent exactly; there is no 99-unit cap. */
export function tryNormalizeRequestedQuantity(value: string | number): number | null {
  const parsed = typeof value === "number" ? value : Number(value.trim());
  if (!Number.isFinite(parsed)) return null;
  const normalized = Math.max(1, Math.trunc(parsed));
  return Number.isSafeInteger(normalized) ? normalized : null;
}

export function normalizeRequestedQuantity(value: string | number): number {
  const normalized = tryNormalizeRequestedQuantity(value);
  if (normalized === null) {
    throw new RangeError("Digite uma quantidade que possa ser calculada com precisão.");
  }
  return normalized;
}

export function addRequestedQuantities(current: number, added: number): number {
  return normalizeRequestedQuantity(current + added);
}

export function calculateLineAmountCents(unitAmountCents: number, quantity: number): number {
  if (!Number.isSafeInteger(unitAmountCents) || unitAmountCents < 1 || !Number.isSafeInteger(quantity) || quantity < 1) {
    throw new RangeError(UNSAFE_AMOUNT_MESSAGE);
  }
  const amount = unitAmountCents * quantity;
  if (!Number.isSafeInteger(amount)) throw new RangeError(UNSAFE_AMOUNT_MESSAGE);
  return amount;
}

export function sumSafeCents(amounts: number[]): number {
  let total = 0;
  for (const amount of amounts) {
    if (!Number.isSafeInteger(amount) || amount < 0) throw new RangeError(UNSAFE_AMOUNT_MESSAGE);
    total += amount;
    if (!Number.isSafeInteger(total)) throw new RangeError(UNSAFE_AMOUNT_MESSAGE);
  }
  return total;
}

export function getUnitAmountCents(product: Product, choice: Pick<CartChoice, "relay"> = {}): number {
  return product.priceCents + (product.category === "SMD" && choice.relay ? RELAY_ADDON_CENTS : 0);
}

export function formatCartVariant(product: Product, choice: Pick<CartChoice, "armSize" | "relay">): string {
  if (product.category !== "SMD") return "linha COB";
  const arm = choice.armSize === "2.5" ? '2,5"' : '2"';
  return `braço ${arm} · ${choice.relay ? "com base relê + relê" : "sem base relê"}`;
}

export function priceCart(choices: CartChoice[]): PricedCartLine[] {
  if (choices.length < 1 || choices.length > 30) throw new Error("O carrinho deve conter entre 1 e 30 itens.");
  return choices.map(choice => {
    const product = products.find(item => item.id === choice.productId);
    if (!product) throw new Error("Produto inválido.");
    if (!Number.isSafeInteger(choice.quantity) || choice.quantity < 1) {
      throw new Error("Quantidade inválida.");
    }
    if (product.category === "SMD" && choice.armSize !== "2" && choice.armSize !== "2.5") {
      throw new Error("Escolha o diâmetro do braço para a luminária SMD.");
    }
    if (product.category === "COB" && (choice.armSize || choice.relay)) {
      throw new Error("Opções de braço e base relê aplicam-se apenas à linha SMD.");
    }
    const unitAmountCents = getUnitAmountCents(product, choice);
    const lineAmountCents = calculateLineAmountCents(unitAmountCents, choice.quantity);
    const label = `${product.title} · ${formatCartVariant(product, choice)}`;
    return { ...choice, product, unitAmountCents, lineAmountCents, label };
  });
}

export function cartTotalCents(lines: PricedCartLine[]): number {
  return sumSafeCents(lines.map(line => line.lineAmountCents));
}

export function subscriptionInterval(months: number) {
  if (months === 0) return undefined;
  if (![1, 3, 6, 12].includes(months)) throw new Error("Escolha uma frequência válida.");
  return { interval: "month" as const, interval_count: months };
}
