import { formatBRL } from "./catalog";
import { calculateLineAmountCents, sumSafeCents } from "./cart";

export type WhatsAppQuoteItem = {
  productName: string;
  quantity: number;
  unitAmountCents: number;
  variant?: string;
};

export function normalizeWhatsAppNumber(input: string) {
  const digits = input.replace(/\D/g, "");
  const number = digits.startsWith("55") ? digits : `55${digits}`;
  if (!/^55\d{10,11}$/.test(number)) {
    throw new Error("Informe um WhatsApp válido com DDD.");
  }
  return number;
}

export function buildWhatsAppMessageUrl(phone: string, message: string) {
  const text = message.trim();
  if (!text) throw new Error("Escreva uma mensagem para abrir o WhatsApp.");
  return `https://wa.me/${normalizeWhatsAppNumber(phone)}?text=${encodeURIComponent(text)}`;
}

export function buildWhatsAppQuoteUrl(
  phone: string,
  items: WhatsAppQuoteItem[],
  subtotalCents: number,
) {
  if (!items.length) throw new Error("Adicione um produto antes de pedir orçamento.");
  const lineTotals = items.map(item => {
    if (typeof item.productName !== "string" || !item.productName.trim()) {
      throw new Error("O orçamento contém um produto sem nome.");
    }
    return calculateLineAmountCents(item.unitAmountCents, item.quantity);
  });
  const computedSubtotalCents = sumSafeCents(lineTotals);
  if (!Number.isSafeInteger(subtotalCents) || subtotalCents !== computedSubtotalCents) {
    throw new Error("O subtotal do orçamento não corresponde aos produtos.");
  }
  const itemLines = items.map((item, index) => {
    const variant = item.variant?.trim();
    return `• ${item.quantity}× ${item.productName.trim()}${variant ? ` — ${variant}` : ""}\n  Unitário: ${formatBRL(item.unitAmountCents)} · Total: ${formatBRL(lineTotals[index])}`;
  });
  const message = [
    "Olá! Gostaria de um orçamento da Blazute Iluminação:",
    "",
    ...itemLines,
    "",
    `Subtotal dos produtos: ${formatBRL(computedSubtotalCents)}`,
    "Frete combinado à parte.",
    "Por favor, confirme disponibilidade e o valor do frete.",
  ].join("\n");
  return buildWhatsAppMessageUrl(phone, message);
}
