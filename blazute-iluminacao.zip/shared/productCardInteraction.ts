const INTERACTIVE_CONTROL_TAGS = new Set(["BUTTON", "A", "INPUT", "SELECT"]);

export function shouldOpenProductFromCardClick(targetIsInteractiveControl: boolean) {
  return !targetIsInteractiveControl;
}

export function shouldOpenProductFromCardKey(key: string, focusIsOnCard: boolean) {
  return focusIsOnCard && (key === "Enter" || key === " ");
}

export function isInteractiveProductCardTag(tagName: string) {
  return INTERACTIVE_CONTROL_TAGS.has(tagName.toUpperCase());
}
