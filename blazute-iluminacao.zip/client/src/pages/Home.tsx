import { useMemo, useState } from "react";
import { ArrowLeft, ArrowRight, BadgeCheck, ChevronDown, Minus, Plus, ShoppingBag, ShieldCheck, Sparkles, Trash2, Truck, X, Zap } from "lucide-react";
import { toast } from "sonner";
import { products, formatBRL, getCatalogProduct, getStartingPriceCents, type Product } from "@shared/catalog";
import { companyInfo } from "@shared/companyInfo";
import { addRequestedQuantities, calculateLineAmountCents, cartTotalCents, defaultCartChoiceForProduct, formatCartVariant, getUnitAmountCents, normalizeRequestedQuantity, priceCart, RELAY_ADDON_CENTS, tryNormalizeRequestedQuantity, type CartChoice } from "@shared/cart";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { buildWhatsAppMessageUrl, buildWhatsAppQuoteUrl } from "@shared/whatsappQuote";
import { isInteractiveProductCardTag, shouldOpenProductFromCardClick, shouldOpenProductFromCardKey } from "@shared/productCardInteraction";

const BRAND = "/manus-storage/logo-blazute_a367ea27.jpeg";
const heroSmdProduct = getCatalogProduct("smd-200");
const heroCobProduct = getCatalogProduct("cob-200");

function WhatsAppIcon({ size = 18 }: { size?: number }) {
  return <svg width={size} height={size} viewBox="0 0 24 24" fill="currentColor" aria-hidden="true" focusable="false"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413Z" /></svg>;
}

function getProductDescription(product: Product) {
  const spec = product.spec;
  if (!spec) return `${product.title}. Luminária pública da linha COB. A ficha técnica detalhada desta linha não foi fornecida; consulte a Blazute para confirmar tensão, fluxo luminoso, proteção e certificação do modelo.`;
  return `${product.title}, luminária pública LED com proteção IP66 e certificação pelo Inmetro. Desenvolvida para projetos viários, com eficiência anunciada de ${product.highlight ?? `${spec.efficacyLmW} lm/W`}. Confira os dados completos do modelo na ficha técnica abaixo.`;
}

function TechnicalSpecSheet({ product }: { product: Product }) {
  if (!product.spec) return <section className="technical-sheet" aria-label="Ficha técnica"><div className="technical-sheet-heading"><span>FICHA TÉCNICA</span><small>LINHA COB</small></div><p className="technical-sheet-note">As especificações detalhadas da linha COB não foram fornecidas. Consulte a Blazute para confirmar os dados técnicos deste modelo.</p></section>;
  const spec = product.spec;
  const rows = [
    ["Potência nominal", `${product.watts} W`], ["Modelo", spec.model], ["Tensão de ensaio", spec.testVoltage],
    ["Frequência", spec.frequency], ["Potência ensaiada", `${spec.testPowerW} W`], ["Fator de potência", spec.powerFactor],
    ["Fluxo luminoso", `${spec.luminousFluxLm} lm`], ["Eficiência energética (EE da ficha)", `${spec.efficacyLmW} lm/W`],
    ["IRC", spec.cri], ["Temperatura de cor", spec.cct], ["Proteção", product.ip66 ? "IP66" : "Não informada"],
    ["Certificação", product.inmetro ? "Inmetro" : "Não informada"],
  ];
  return <section className="technical-sheet" aria-label={`Ficha técnica de ${product.title}`}><div className="technical-sheet-heading"><span>FICHA TÉCNICA</span>{product.inmetro && <small><BadgeCheck size={13} /> CERTIFICADA PELO INMETRO</small>}</div><dl className="technical-sheet-grid">{rows.map(([label, value]) => <div key={label}><dt>{label}</dt><dd>{value}</dd></div>)}</dl></section>;
}

function ProductCard({ product, onOpen, onAdd }: { product: Product; onOpen: (product: Product) => void; onAdd: (choice: CartChoice) => void }) {
  return <article className="product-card product-card-interactive" tabIndex={0} aria-label={`Abrir ficha de ${product.title}`} onClick={event => { const interactiveTag = (event.target as Element).closest("button, a, input, select")?.tagName ?? ""; if (!shouldOpenProductFromCardClick(isInteractiveProductCardTag(interactiveTag))) return; onOpen(product); }} onKeyDown={event => { if (!shouldOpenProductFromCardKey(event.key, event.target === event.currentTarget)) return; event.preventDefault(); onOpen(product); }}>
    <button type="button" className="product-open-trigger" onClick={() => onOpen(product)} aria-label={`Ver detalhes de ${product.title}`}><div className="product-photo"><img src={product.image} alt={product.imageAlt} loading="lazy" /><span className="power-tag">{product.shortTitle}</span>{product.inmetro && <span className="quality-chip"><BadgeCheck size={13} /> INMETRO</span>}<span className="photo-note">Imagem ilustrativa</span></div></button>
    <div className="product-body"><div className="product-category">PÚBLICA {product.category}{product.ip66 ? " · IP66" : ""}</div><h3><button type="button" className="product-title-button" onClick={() => onOpen(product)}>{product.title}</button></h3>
      {product.highlight && <p className="product-efficiency"><Zap size={15} /> {product.highlight}</p>}
      <div className="price-line"><span className="price-prefix">a partir de</span><strong>{formatBRL(product.priceCents)}</strong><span className="unit-label">/ un.</span></div>
      {product.category === "COB" && <p className="simple-meta">Luminária pública de LED · linha COB</p>}
      <button className="add-to-cart" type="button" onClick={event => { event.stopPropagation(); onAdd(defaultCartChoiceForProduct(product)); }}><Plus size={16} /> Adicionar ao carrinho <span>{formatBRL(product.priceCents)}</span></button>
    </div>
  </article>;
}

export default function Home() {
  const [cart, setCart] = useState<CartChoice[]>([]);
  const [cartOpen, setCartOpen] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [descriptionExpanded, setDescriptionExpanded] = useState(false);
  const [detailArmSize, setDetailArmSize] = useState<"2" | "2.5">("2");
  const [detailRelay, setDetailRelay] = useState(false);
  const [detailQuantityText, setDetailQuantityText] = useState("1");
  const cartLines = useMemo(() => (cart.length ? priceCart(cart) : []).map(line => ({
    ...line,
    unitCents: line.unitAmountCents,
    subtotal: line.lineAmountCents,
    variant: formatCartVariant(line.product, line),
  })), [cart]);
  const total = useMemo(() => cartTotalCents(cartLines), [cartLines]);
  const itemCount = cart.reduce((sum, line) => sum + line.quantity, 0);
  const quickWhatsAppUrl = useMemo(() => buildWhatsAppMessageUrl(companyInfo.whatsapp, "Olá! Vi o portfólio de luminárias públicas e gostaria de mais informações."), []);
  const detailUnitPrice = selectedProduct ? getUnitAmountCents(selectedProduct, { relay: detailRelay }) : 0;
  const detailQuantity = tryNormalizeRequestedQuantity(detailQuantityText);
  let detailSubtotalCents: number | null = null;
  if (detailQuantity !== null && selectedProduct) {
    try {
      detailSubtotalCents = calculateLineAmountCents(detailUnitPrice, detailQuantity);
    } catch {
      detailSubtotalCents = null;
    }
  }

  const openProduct = (product: Product) => {
    setSelectedProduct(product);
    setDescriptionExpanded(false);
    setDetailArmSize("2");
    setDetailRelay(false);
    setDetailQuantityText("1");
  };

  const addToCart = (choice: CartChoice): boolean => {
    const keyOf = (item: CartChoice) => `${item.productId}-${item.armSize ?? ""}-${item.relay ? 1 : 0}`;
    let quantity: number;
    try {
      quantity = normalizeRequestedQuantity(choice.quantity);
      const existing = cart.find(item => keyOf(item) === keyOf(choice));
      const nextCart = existing
        ? cart.map(item => keyOf(item) === keyOf(choice) ? { ...item, quantity: addRequestedQuantities(item.quantity, quantity) } : item)
        : [...cart, { ...choice, quantity }];
      if (nextCart.length > 30) throw new Error("O carrinho atingiu o máximo de combinações diferentes.");
      cartTotalCents(priceCart(nextCart));
      setCart(nextCart);
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "A quantidade é grande demais para calcular com segurança.");
      return false;
    }
    toast.success(`${quantity} ${quantity === 1 ? "unidade adicionada" : "unidades adicionadas"} ao carrinho`);
    return true;
  };
  const changeQuantity = (line: CartChoice, delta: number) => {
    try {
      const nextCart = cart.flatMap(item => {
        if (item.productId !== line.productId || item.armSize !== line.armSize || item.relay !== line.relay) return [item];
        const quantity = item.quantity + delta;
        return quantity < 1 ? [] : [{ ...item, quantity: normalizeRequestedQuantity(quantity) }];
      });
      if (nextCart.length) cartTotalCents(priceCart(nextCart));
      setCart(nextCart);
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Não foi possível calcular esta quantidade.");
    }
  };
  const removeLine = (line: CartChoice) => setCart(current => current.filter(item => !(item.productId === line.productId && item.armSize === line.armSize && item.relay === line.relay)));

  const requestWhatsAppQuote = () => {
    try {
      const url = buildWhatsAppQuoteUrl(companyInfo.whatsapp, cartLines.map(line => ({
        productName: line.product.title,
        quantity: line.quantity,
        unitAmountCents: line.unitCents,
        variant: line.variant.replace(/^ · /, ""),
      })), total);
      window.open(url, "_blank", "noopener,noreferrer");
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Não foi possível preparar o orçamento.");
    }
  };

  const addSelectedProduct = () => {
    if (!selectedProduct) return;
    if (detailQuantity === null || detailSubtotalCents === null) {
      toast.error("Digite uma quantidade que possa ser calculada com precisão.");
      return;
    }
    const wasAdded = addToCart({
      productId: selectedProduct.id,
      quantity: detailQuantity,
      ...(selectedProduct.category === "SMD" ? { armSize: detailArmSize, relay: detailRelay } : {}),
    });
    if (!wasAdded) return;
    setSelectedProduct(null);
  };

  return <div className="store-shell">
    <div className="promo-strip"><Sparkles size={14} /><span>PREÇO DIRETO QUE ACENDE SEU PROJETO</span><span className="promo-divider">·</span><span>Luminárias públicas a partir de <b>{formatBRL(getStartingPriceCents())}</b></span><ArrowRight size={14} /></div>
    <header className="site-header"><a href="#inicio" className="brand" aria-label="Blazute Iluminação — início"><img src={BRAND} alt="Logo Blazute Iluminação" /><span className="brand-wordmark"><b>BLAZUTE</b><small>ILUMINAÇÃO</small></span></a>
      <nav aria-label="Menu principal" className="main-nav"><a href="#smd">Luminária pública SMD</a><a href="#cob">Luminária pública COB</a><a href="#vantagens">Por que a Blazute?</a></nav>
      <button className="header-cart" onClick={() => setCartOpen(true)} aria-label={`Abrir carrinho com ${itemCount} itens`}><ShoppingBag size={18} /><span>Carrinho</span><b>{itemCount}</b></button></header>
    <main id="inicio">

      <section id="smd" className="catalog-section container"><div className="section-head"><div><span className="section-kicker">TECNOLOGIA PARA A CIDADE</span><h2>Luminária pública <em>SMD</em></h2><p>Eficiência, proteção IP66 e especificações técnicas claras — com preços em destaque.</p></div><span className="section-index">01 <i>—</i> 05</span></div><div className="product-grid smd-grid">{products.filter(product => product.category === "SMD").map(product => <ProductCard key={product.id} product={product} onOpen={openProduct} onAdd={addToCart} />)}</div></section>
      <section className="spec-callout container"><div className="spec-symbol"><Zap size={23} /></div><div><b>Especificação à vista, decisão mais simples.</b><p>Veja modelo, tensão, fluxo luminoso, eficiência, IRC e temperatura de cor nas fichas de cada SMD.</p></div><a href="#smd">Ver produtos <ArrowRight size={15} /></a></section>
      <section id="cob" className="catalog-section cob-section"><div className="container"><div className="section-head"><div><span className="section-kicker">POTÊNCIA PARA TODO TAMANHO DE PROJETO</span><h2>Luminária pública <em>COB</em></h2><p>Opções de 50W a 400W com o preço para comparar de primeira.</p></div><span className="section-index">06 <i>—</i> 11</span></div><div className="product-grid cob-grid">{products.filter(product => product.category === "COB").map(product => <ProductCard key={product.id} product={product} onOpen={openProduct} onAdd={addToCart} />)}</div></div></section>
      <div className="trust-rail"><div><BadgeCheck size={18} /><span>Modelos SMD certificados pelo Inmetro</span></div><div><ShieldCheck size={18} /><span>Linha SMD com proteção IP66</span></div><div><Truck size={18} /><span>Atendimento para projetos e compras em volume</span></div><div><WhatsAppIcon size={17} /><span>Orçamento confirmado direto com a Blazute</span></div></div>

      <section id="vantagens" className="why-section container"><div className="why-heading"><span className="section-kicker">BLAZUTE ILUMINAÇÃO</span><h2>Iluminação pública,<br /><em>sem complicar.</em></h2><p>Preço na primeira tela, especificação no produto e orçamento direto no WhatsApp.</p></div><div className="why-list"><div><span>01</span><div><b>Preço claro desde o início</b><p>Compare as potências e os valores sem precisar pedir orçamento para cada item.</p></div></div><div><span>02</span><div><b>Opções que fazem sentido</b><p>Escolha braço de 2″ ou 2,5″ e acrescente base relê na linha SMD.</p></div></div><div><span>03</span><div><b>Conversa rápida com a Blazute</b><p>Monte seu pedido, escolha as quantidades e envie os detalhes pelo WhatsApp para confirmar frete e disponibilidade.</p></div></div></div></section>

      <section className="hero container"><div className="hero-copy"><div className="eyebrow"><span className="live-dot" /> ILUMINAÇÃO PÚBLICA · PREÇO COMPETITIVO</div>
        <h1>Luz que transforma.<br /><em>Preço que surpreende.</em></h1><p>Luminárias públicas LED direto para o seu projeto. Escolha a potência, confira o preço e peça em poucos cliques.</p>
        <div className="hero-prices"><a href="#smd"><span>{heroSmdProduct.shortTitle} SMD</span><strong>{formatBRL(heroSmdProduct.priceCents)}</strong><small>IP66 · certificada</small></a><span className="hero-or">ou</span><a href="#cob"><span>{heroCobProduct.shortTitle} COB</span><strong>{formatBRL(heroCobProduct.priceCents)}</strong><small>linha econômica</small></a></div>
        <div className="hero-actions"><a className="hero-button" href="#smd">Ver ofertas <ArrowRight size={17} /></a><span className="hero-note"><WhatsAppIcon size={16} /> Orçamento direto no WhatsApp</span></div></div>
        <div className="hero-visual hero-visual-banner"><img src="/manus-storage/banner-promocional-smd_cc6a6ca7.jpeg" alt="Banner promocional Blazute: luminárias públicas LED SMD certificadas pelo Inmetro" /></div></section>
      <section className="last-call"><div className="container last-call-inner"><div><span className="section-kicker">SEU PRÓXIMO PROJETO COMEÇA AQUI</span><h2>Escolha a potência.<br /><em>O preço já está na tela.</em></h2></div><a href="#smd">Explorar luminárias <ArrowRight size={17} /></a></div></section>

      {/* Penúltima seção: dados cadastrais da empresa */}
      <section className="company-section container" aria-labelledby="company-title"><div className="company-section-heading"><span className="section-kicker">DADOS DA EMPRESA</span><h2 id="company-title">Blazute Iluminação</h2><p>Conheça a empresa por trás das luminárias e fale diretamente com nosso atendimento.</p></div><div className="company-information-grid"><div className="company-information-card company-registration-card"><span className="company-information-label">IDENTIFICAÇÃO</span><dl><div><dt>Razão social</dt><dd>{companyInfo.legalName}</dd></div><div><dt>Nome fantasia</dt><dd>{companyInfo.tradeName}</dd></div><div><dt>CNPJ</dt><dd>{companyInfo.cnpj}</dd></div></dl></div><div className="company-information-card"><span className="company-information-label">ENDEREÇO CADASTRAL</span><address>{companyInfo.address}<br />{companyInfo.neighborhood}<br />{companyInfo.city} — {companyInfo.state}<br />CEP {companyInfo.postalCode}</address></div><div className="company-information-card"><span className="company-information-label">ATIVIDADE PRINCIPAL</span><p>{companyInfo.activity}</p><a className="company-whatsapp-link" href={buildWhatsAppMessageUrl(companyInfo.whatsapp, "Olá! Vi o site da Blazute Iluminação e gostaria de informações sobre a empresa e os produtos.")} target="_blank" rel="noopener noreferrer"><WhatsAppIcon size={18} /> WhatsApp {companyInfo.whatsapp} <ArrowRight size={15} /></a></div></div><p className="company-data-note">Dados cadastrais públicos. Para disponibilidade, frete e pedidos, consulte nosso atendimento.</p></section>
    </main>
    <footer className="site-footer"><div className="footer-brand"><img src={BRAND} alt="" /><div><b>BLAZUTE ILUMINAÇÃO</b><span>Materiais elétricos · iluminação pública LED</span><span>{companyInfo.legalName} · CNPJ {companyInfo.cnpj}</span></div></div><div className="footer-links"><a href="#smd">Linha SMD</a><a href="#cob">Linha COB</a><a href="/admin">Área administrativa</a></div><p>© {new Date().getFullYear()} Blazute Iluminação. Imagens ilustrativas; consulte a ficha técnica de cada modelo antes de pedir seu orçamento.</p></footer>
    <Dialog open={Boolean(selectedProduct)} onOpenChange={open => { if (!open) setSelectedProduct(null); }}>
      {selectedProduct && <DialogContent className="product-dialog-content">
        <div className="product-dialog-layout">
          <div className="product-dialog-photo"><img src={selectedProduct.image} alt={selectedProduct.imageAlt} /><span>{selectedProduct.category === "SMD" ? "LINHA SMD · IP66" : "LINHA COB"}</span></div>
      <div className="product-dialog-info"><div className="product-category">PÚBLICA {selectedProduct.category}{selectedProduct.ip66 ? " · IP66" : ""}{selectedProduct.inmetro ? " · INMETRO" : ""}</div>
            <DialogHeader className="product-dialog-header"><DialogTitle>{selectedProduct.title}</DialogTitle><DialogDescription>{selectedProduct.category === "SMD" ? "Luminária pública LED com proteção IP66 e certificação Inmetro." : "Luminária pública LED da linha COB."} {selectedProduct.highlight ? `Eficiência destacada: ${selectedProduct.highlight}.` : "Consulte a disponibilidade para seu projeto."}</DialogDescription></DialogHeader>
            <div className="product-dialog-price"><span>Preço unitário</span><b>{formatBRL(detailUnitPrice)}</b></div>
            {selectedProduct.category === "SMD" && <div className="product-dialog-options"><label>Diâmetro do braço<select value={detailArmSize} onChange={event => setDetailArmSize(event.target.value as "2" | "2.5")}><option value="2">2 polegadas</option><option value="2.5">2,5 polegadas</option></select></label><label className="dialog-relay-option"><input type="checkbox" checked={detailRelay} onChange={event => setDetailRelay(event.target.checked)} /><span>Com base relê + relê <b>+ {formatBRL(RELAY_ADDON_CENTS)}/un.</b></span></label></div>}
            <div className="product-dialog-quantity"><label htmlFor="product-quantity">Quantidade</label><input id="product-quantity" type="number" inputMode="numeric" min={1} step={1} value={detailQuantityText} onChange={event => setDetailQuantityText(event.target.value)} onBlur={() => { const normalized = tryNormalizeRequestedQuantity(detailQuantityText); if (normalized !== null) setDetailQuantityText(String(normalized)); }} aria-describedby="quantity-guidance" aria-invalid={detailQuantity === null} /><small id="quantity-guidance" role={detailQuantity === null ? "alert" : undefined}>{detailQuantity === null ? "Quantidade fora da faixa que pode ser calculada com precisão." : "Digite a quantidade desejada; sem teto de 99 unidades."}</small></div>
            <div className="product-dialog-subtotal"><span>Subtotal</span><b>{detailSubtotalCents === null ? "—" : formatBRL(detailSubtotalCents)}</b></div>
            <div className="product-description-block"><p className={`product-dialog-description${descriptionExpanded ? " is-expanded" : ""}`}>{getProductDescription(selectedProduct)}</p><button className="product-description-toggle" type="button" onClick={() => setDescriptionExpanded(expanded => !expanded)} aria-expanded={descriptionExpanded}>{descriptionExpanded ? "Ver menos" : "Ver mais"}<ChevronDown size={14} /></button></div>
            <TechnicalSpecSheet product={selectedProduct} />
            <button className="details-add-button" type="button" onClick={addSelectedProduct} disabled={detailQuantity === null || detailSubtotalCents === null}><ShoppingBag size={17} /> Adicionar {detailQuantity ?? "—"} {detailQuantity === 1 ? "unidade" : "unidades"} ao carrinho <ArrowRight size={16} /></button>
          </div>
        </div>
      </DialogContent>}
    </Dialog>
    <a className="floating-whatsapp" href={quickWhatsAppUrl} target="_blank" rel="noopener noreferrer" aria-label="Falar com a Blazute pelo WhatsApp: Olá! Vi o portfólio de luminárias públicas e gostaria de mais informações."><WhatsAppIcon size={25} /><span>Fazer orçamento</span></a>
    <Dialog open={cartOpen} onOpenChange={setCartOpen}>
      <DialogContent className="cart-panel" overlayClassName="cart-backdrop" showCloseButton={false} aria-labelledby="cart-title">
      <header className="cart-header"><button className="cart-back-button" type="button" onClick={() => setCartOpen(false)} aria-label="Voltar para a loja" title="Voltar para a loja"><ArrowLeft size={19} /></button><div><span className="section-kicker">SEU PEDIDO</span><DialogTitle id="cart-title">Carrinho <span>({itemCount})</span></DialogTitle><DialogDescription className="sr-only">Confira quantidades e subtotal, altere seu pedido ou finalize a compra pelo WhatsApp.</DialogDescription></div></header>
      {cartLines.length === 0 ? <div className="cart-empty"><span><ShoppingBag size={27} /></span><h3>Seu carrinho está vazio</h3><p>Escolha suas luminárias e volte por aqui para montar seu orçamento.</p><button onClick={() => setCartOpen(false)}>Ver catálogo <ArrowRight size={16} /></button></div> : <>
        <div className="cart-lines">{cartLines.map((line, index) => { const accessibleVariant = line.variant.replace(/^linha /, ""); const accessibleName = `${line.product.title}${line.product.category === "SMD" ? `, ${accessibleVariant}` : ""}`; return <div className="cart-line" key={`${line.productId}-${line.armSize}-${line.relay}-${index}`}><img src={line.product.image} alt="" /><div className="cart-line-info"><b>{line.product.title}</b><small>{accessibleVariant}</small><strong>{formatBRL(line.subtotal)}</strong><div className="quantity-control"><button aria-label={`Diminuir quantidade de ${accessibleName}`} onClick={() => changeQuantity(line, -1)}><Minus size={14} /></button><span>{line.quantity}</span><button aria-label={`Aumentar quantidade de ${accessibleName}`} onClick={() => changeQuantity(line, 1)}><Plus size={14} /></button></div></div><button className="remove-line" onClick={() => removeLine(line)} aria-label={`Remover ${accessibleName} do carrinho`}><Trash2 size={16} /></button></div>; })}</div>
        <div className="cart-summary"><div className="cart-total"><span>Subtotal</span><b>{formatBRL(total)}</b></div><div className="freight-note">Frete combinado separadamente; o subtotal não inclui o envio.</div>
        <button className="whatsapp-quote" type="button" onClick={requestWhatsAppQuote}><WhatsAppIcon size={19} /> Finalizar minha compra no WhatsApp <ArrowRight size={16} /></button>
        <p className="whatsapp-hint">O pedido abrirá pronto para enviar; confirme o envio na conversa do WhatsApp.</p></div>
      </>}
      </DialogContent>
    </Dialog>
  </div>;
}
