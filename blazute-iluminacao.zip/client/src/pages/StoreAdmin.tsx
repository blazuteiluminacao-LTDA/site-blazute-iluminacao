import { useAuth } from "@/_core/hooks/useAuth";
import { startLogin } from "@/const";
import { trpc } from "@/lib/trpc";
import { formatBRL } from "@shared/catalog";
import { ArrowLeft, LogIn, RefreshCw, ShieldCheck, Users, WalletCards } from "lucide-react";
import { Button } from "@/components/ui/button";

function statusName(status: string) {
  return ({ pending: "Pendente", paid: "Pago", failed: "Falhou", cancelled: "Cancelado" } as Record<string, string>)[status] ?? status;
}

export default function StoreAdmin() {
  const auth = useAuth();
  const isAdmin = auth.user?.role === "admin";
  const report = trpc.store.adminReport.useQuery(undefined, { enabled: isAdmin, retry: false });

  return <main className="admin-shell">
    <header className="admin-header"><a href="/" className="admin-brand"><img src="/manus-storage/logo-blazute_a367ea27.jpeg" alt="" /><span><b>BLAZUTE</b><small>PAINEL DA LOJA</small></span></a><a href="/" className="admin-back"><ArrowLeft size={16} /> Voltar à loja</a></header>
    <div className="admin-content">
      <div className="admin-title"><div><span className="section-kicker">GESTÃO DA LOJA</span><h1>Clientes e pedidos</h1><p>Dados operacionais da loja Blazute Iluminação.</p></div><Button variant="outline" onClick={() => report.refetch()} disabled={!isAdmin || report.isFetching}><RefreshCw size={16} className={report.isFetching ? "spin" : ""} /> Atualizar</Button></div>
      {auth.loading && <div className="admin-state">Verificando acesso…</div>}
      {!auth.loading && !auth.isAuthenticated && <section className="admin-gate"><div className="admin-gate-icon"><ShieldCheck size={27} /></div><h2>Acesso da equipe</h2><p>Entre com a conta proprietária para visualizar a base de clientes e os pedidos.</p><Button onClick={() => startLogin()}><LogIn size={16} /> Entrar como administrador</Button></section>}
      {!auth.loading && auth.isAuthenticated && !isAdmin && <section className="admin-gate"><div className="admin-gate-icon"><ShieldCheck size={27} /></div><h2>Acesso restrito</h2><p>Esta área está disponível somente para o administrador da loja.</p></section>}
      {isAdmin && <>
        {report.isLoading && <div className="admin-state">Carregando registros…</div>}
        {report.error && <div className="admin-error">Não foi possível carregar os dados do banco. Tente atualizar a página.</div>}
        {report.data && <>
          <div className="admin-stats"><div><span><Users size={17} /> CLIENTES</span><strong>{report.data.customers.length}</strong><small>registros recentes</small></div><div><span><WalletCards size={17} /> PEDIDOS</span><strong>{report.data.orders.length}</strong><small>registros recentes</small></div></div>
          <section className="admin-table-section"><div className="admin-table-heading"><div><h2>Pedidos</h2><p>Até 50 pedidos mais recentes · pagamentos processados pelo Stripe</p></div></div>
            {report.data.orders.length === 0 ? <div className="admin-empty">Os primeiros pedidos aparecerão aqui.</div> : <div className="table-scroll"><table><thead><tr><th>Referência</th><th>Cliente</th><th>Produtos</th><th>Entrega</th><th>Recorrência</th><th>Total</th><th>Status</th><th>Data</th></tr></thead><tbody>{report.data.orders.map(order => {
              let items: { productName?: string; quantity?: number; label?: string }[] = [];
              try { items = JSON.parse(order.items); } catch { items = []; }
              let shipping = "Aguardando checkout";
              try { if (order.shippingAddress) { const address = JSON.parse(order.shippingAddress); shipping = [address.line1, address.line2, address.city, address.state, address.postalCode].filter(Boolean).join(", ") || "Endereço recebido"; } } catch { shipping = "Endereço registrado"; }
              const cadence = order.recurrenceMonths ? (order.recurrenceMonths === 1 ? "Mensal" : `A cada ${order.recurrenceMonths} meses`) : "Única";
              return <tr key={order.reference}><td><code>{order.reference.slice(0, 8).toUpperCase()}</code></td><td><b>{order.customerName ?? "—"}</b><small>{order.customerEmail ?? ""}</small></td><td>{items.map(item => `${item.quantity ?? 1}× ${item.productName ?? item.label ?? "Item"}`).join(", ")}</td><td>{shipping}</td><td>{cadence}</td><td><b>{formatBRL(order.amountCents)}</b></td><td><span className={`status-pill status-${order.status}`}>{statusName(order.status)}</span></td><td>{new Date(order.createdAt).toLocaleDateString("pt-BR")}</td></tr>;
            })}</tbody></table></div>}
          </section>
          <section className="admin-table-section"><div className="admin-table-heading"><div><h2>Clientes</h2><p>Contatos informados nos pedidos, mantidos no banco da loja.</p></div></div>
            {report.data.customers.length === 0 ? <div className="admin-empty">Nenhum cliente cadastrado ainda.</div> : <div className="table-scroll"><table><thead><tr><th>Cliente</th><th>E-mail</th><th>Telefone</th><th>Cadastro</th></tr></thead><tbody>{report.data.customers.map(customer => <tr key={customer.id}><td><b>{customer.name}</b></td><td>{customer.email}</td><td>{customer.phone || "—"}</td><td>{new Date(customer.createdAt).toLocaleDateString("pt-BR")}</td></tr>)}</tbody></table></div>}
          </section>
        </>}
      </>}
    </div>
    <footer className="admin-footer">Blazute Iluminação · Dados de clientes acessíveis apenas à equipe autorizada.</footer>
  </main>;
}
