CREATE TABLE `store_customers` (
	`id` int AUTO_INCREMENT NOT NULL,
	`name` varchar(191) NOT NULL,
	`email` varchar(320) NOT NULL,
	`phone` varchar(40),
	`stripeCustomerId` varchar(255),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `store_customers_id` PRIMARY KEY(`id`),
	CONSTRAINT `store_customers_email_unique` UNIQUE(`email`),
	CONSTRAINT `store_customers_stripe_id_unique` UNIQUE(`stripeCustomerId`)
);
--> statement-breakpoint
CREATE TABLE `store_orders` (
	`id` int AUTO_INCREMENT NOT NULL,
	`reference` varchar(64) NOT NULL,
	`customerId` int,
	`status` enum('pending','paid','failed','cancelled') NOT NULL DEFAULT 'pending',
	`items` text NOT NULL,
	`amountCents` int NOT NULL,
	`recurrenceMonths` int NOT NULL DEFAULT 0,
	`currency` varchar(3) NOT NULL DEFAULT 'brl',
	`stripeCheckoutSessionId` varchar(255),
	`stripeSubscriptionId` varchar(255),
	`stripePaymentIntentId` varchar(255),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `store_orders_id` PRIMARY KEY(`id`),
	CONSTRAINT `store_orders_reference_unique` UNIQUE(`reference`),
	CONSTRAINT `store_orders_checkout_session_unique` UNIQUE(`stripeCheckoutSessionId`),
	CONSTRAINT `store_orders_subscription_unique` UNIQUE(`stripeSubscriptionId`)
);
--> statement-breakpoint
ALTER TABLE `store_orders` ADD CONSTRAINT `store_orders_customerId_store_customers_id_fk` FOREIGN KEY (`customerId`) REFERENCES `store_customers`(`id`) ON DELETE no action ON UPDATE no action;