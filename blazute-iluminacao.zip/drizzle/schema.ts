import { bigint, int, mysqlEnum, mysqlTable, text, timestamp, varchar, uniqueIndex } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  /**
   * Surrogate primary key. Auto-incremented numeric value managed by the database.
   * Use this for relations between tables.
   */
  id: int("id").autoincrement().primaryKey(),
  /** Manus OAuth identifier (openId) returned from the OAuth callback. Unique per user. */
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/** Customer contact details are stored for order fulfilment; payment credentials stay with Stripe. */
export const customers = mysqlTable("store_customers", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 191 }).notNull(),
  email: varchar("email", { length: 320 }).notNull(),
  phone: varchar("phone", { length: 40 }),
  stripeCustomerId: varchar("stripeCustomerId", { length: 255 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, table => ({
  emailUnique: uniqueIndex("store_customers_email_unique").on(table.email),
  stripeIdUnique: uniqueIndex("store_customers_stripe_id_unique").on(table.stripeCustomerId),
}));

/** Fulfilment snapshot and schedule belong locally; sensitive payment data remains exclusively in Stripe. */
export const orders = mysqlTable("store_orders", {
  id: int("id").autoincrement().primaryKey(),
  reference: varchar("reference", { length: 64 }).notNull().unique(),
  customerId: int("customerId").references(() => customers.id),
  status: mysqlEnum("status", ["pending", "paid", "failed", "cancelled"]).default("pending").notNull(),
  items: text("items").notNull(),
  shippingAddress: text("shippingAddress"),
  amountCents: bigint("amountCents", { mode: "number" }).notNull(),
  recurrenceMonths: int("recurrenceMonths").notNull().default(0),
  currency: varchar("currency", { length: 3 }).notNull().default("brl"),
  stripeCheckoutSessionId: varchar("stripeCheckoutSessionId", { length: 255 }),
  stripeSubscriptionId: varchar("stripeSubscriptionId", { length: 255 }),
  stripePaymentIntentId: varchar("stripePaymentIntentId", { length: 255 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, table => ({
  checkoutSessionUnique: uniqueIndex("store_orders_checkout_session_unique").on(table.stripeCheckoutSessionId),
  subscriptionUnique: uniqueIndex("store_orders_subscription_unique").on(table.stripeSubscriptionId),
}));
