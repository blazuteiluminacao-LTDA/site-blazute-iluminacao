# Blazute Iluminação — loja de luminárias públicas LED

Loja responsiva de luminárias públicas SMD e COB, com tema escuro em preto, laranja e creme, preços em destaque, catálogo técnico, carrinho flutuante e orçamento por WhatsApp.

## O que está incluído

- **Catálogo:** cinco modelos SMD (50W–200W) e seis modelos COB (50W–400W), com preços em reais.
- **Configuração SMD:** braço de 2″ ou 2,5″; opcional de base relê + relê por R$ 23,00 por unidade.
- **Ficha do produto:** diálogo em tela cheia com especificações, preço/subtotal, campo de quantidade sem teto comercial e validação de precisão numérica.
- **Carrinho:** drawer lateral responsivo e acessível (fechamento por Escape, foco controlado e lista rolável), com subtotal validado.
- **WhatsApp:** a loja prepara a mensagem com produtos, variantes, quantidades, preços e subtotal. O comprador ainda confirma o envio no WhatsApp. Frete fica separado e deve ser confirmado na conversa.
- **Contato flutuante:** mensagem “Olá! Vi o portfólio de luminárias públicas e gostaria de mais informações.”
- **Dados empresariais:** Blazute Iluminação, CNPJ 62.881.997/0001-93.
- **Área administrativa:** rota `/admin`, protegida por autenticação e função `admin`.

### Orçamentos WhatsApp e persistência de clientes

O caminho apresentado ao comprador neste momento é **orçamento pelo WhatsApp**, sem formulário de pagamento no carrinho. Como esse caminho apenas abre uma mensagem pré-preenchida, o aplicativo **não recebe nem grava automaticamente** o nome/telefone do comprador ou o orçamento enviado por WhatsApp. A área `/admin` lista os clientes e pedidos que forem persistidos pelo checkout Stripe; uma conversa iniciada no WhatsApp, por si só, não cria registro no banco.

O código mantém o checkout Stripe de pagamento único/recorrente e o webhook, mas esse fluxo não está ligado ao CTA atual do carrinho. Para ativá-lo no futuro, configure as credenciais e conecte uma interface de checkout deliberadamente — isso mudaria a jornada atual de orçamento.

## Stack

- React 19, TypeScript, Vite, Tailwind CSS 4
- Express 4 e tRPC 11
- Drizzle ORM com MySQL/TiDB
- Manus OAuth para sessão administrativa
- Stripe SDK (código de checkout e webhook opcional)

## Requisitos

- Node.js 22 ou versão LTS compatível
- **pnpm 11.25.0** (versão fixada no `package.json`)
- Banco MySQL/TiDB para persistência e autenticação administrativa

## Desenvolvimento local

```bash
pnpm install
pnpm dev
```

O servidor de desenvolvimento usa a porta 3000. Para validação:

```bash
pnpm check
pnpm test
pnpm build
```

## Banco de dados e migrações

As tabelas Drizzle ficam em `drizzle/schema.ts`; os arquivos SQL versionados ficam em `drizzle/`. Para aplicar as migrações numa instalação configurada:

```bash
pnpm drizzle-kit migrate
```

`pnpm db:push` executa geração e aplicação de migração; antes de usar num ambiente compartilhado, revise o SQL gerado e confirme que a alteração corresponde ao esquema pretendido. O total de pedidos é armazenado em centavos num `BIGINT`; a lógica da aplicação continua impondo a faixa segura de inteiro JavaScript.

## Configuração e dados sensíveis

Configure os valores no gerenciador de secrets da plataforma/ambiente de deploy — **não coloque credenciais no ZIP, no Git ou no código**.

Variáveis principais:

| Variável | Uso |
| --- | --- |
| `DATABASE_URL` | Conexão MySQL/TiDB |
| `JWT_SECRET` | Assinatura do cookie de sessão |
| `VITE_APP_ID` | Aplicação OAuth Manus |
| `OAUTH_SERVER_URL` | Endpoint servidor OAuth Manus |
| `OWNER_OPEN_ID` | `openId` do proprietário, usado para atribuir a função administrativa |
| `STRIPE_SECRET_KEY` | Opcional; requerido apenas pelo endpoint de checkout Stripe |
| `STRIPE_WEBHOOK_SECRET` | Opcional; assinatura do webhook Stripe |

Endpoint de webhook Stripe: `POST /api/stripe/webhook`. Não configure esse fluxo apenas para habilitar o orçamento por WhatsApp.

## Imagens

O código referencia os assets do armazenamento Manus em `/manus-storage/`. Para manter os arquivos-fonte reunidos, o ZIP também contém cópias em `project-assets/site-media/` (logo, banners e imagens SMD/COB). Num deploy fora do armazenamento atual, envie essas imagens ao seu serviço de arquivos e atualize os caminhos correspondentes em `shared/catalog.ts` e `client/src/pages/Home.tsx`.

## Observações sobre o catálogo

- Os dados técnicos SMD exibidos refletem as fichas fornecidas para cada modelo; COB aparece com aviso para confirmar especificações, porque uma tabela técnica COB não foi fornecida.
- Imagens são ilustrativas. Confirme a ficha e a disponibilidade com a Blazute antes de comprar.
- O subtotal mostrado não inclui frete.
